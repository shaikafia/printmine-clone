import { products } from '../data/products';
import { Product } from '../types';

export const formatPrice = (price: number): string => {
  return `₹${price.toLocaleString('en-IN')}`;
};

export const getProduct = (id: string): Product | undefined => {
  return products.find(product => product.id === id);
};

export const getProductPrice = (
  productId: string, 
  selectedOptions?: Record<string, string>
): number => {
  const product = getProduct(productId);
  
  if (!product) return 0;
  
  let totalPrice = product.price;
  
  if (selectedOptions && product.customizationOptions) {
    product.customizationOptions.forEach(option => {
      const selectedValue = selectedOptions[option.id];
      
      if (selectedValue && option.additionalPrice && option.additionalPrice[selectedValue]) {
        totalPrice += option.additionalPrice[selectedValue];
      }
    });
  }
  
  return totalPrice;
};

export const truncateText = (text: string, maxLength: number): string => {
  if (text.length <= maxLength) return text;
  return text.slice(0, maxLength) + '...';
};

export const generateOrderId = (): string => {
  return 'ORD' + Math.random().toString(36).substring(2, 8).toUpperCase();
};