import React from 'react';
import { Link, useLocation, Navigate } from 'react-router-dom';
import { CheckCircle, ShoppingBag, Truck, Phone } from 'lucide-react';
import Button from '../components/UI/Button';
import { formatPrice } from '../utils/helpers';

interface OrderSuccessState {
  orderId: string;
  total: number;
  shippingAddress: string;
  paymentMethod: string;
}

const OrderSuccess: React.FC = () => {
  const location = useLocation();
  const state = location.state as OrderSuccessState;
  
  // If no order state, redirect to home
  if (!state || !state.orderId) {
    return <Navigate to="/" replace />;
  }
  
  const formatPaymentMethod = (method: string) => {
    switch (method) {
      case 'card': return 'Credit/Debit Card';
      case 'upi': return 'UPI';
      case 'cod': return 'Cash on Delivery';
      default: return method;
    }
  };

  return (
    <div className="bg-gray-50 pt-24 pb-12 min-h-screen">
      <div className="container mx-auto px-4">
        <div className="max-w-2xl mx-auto">
          <div className="bg-white rounded-lg shadow-sm p-8 text-center">
            <div className="w-16 h-16 bg-green-100 rounded-full flex items-center justify-center mx-auto mb-6">
              <CheckCircle size={32} className="text-green-600" />
            </div>
            
            <h1 className="text-3xl font-bold text-gray-900 mb-2">Order Confirmed</h1>
            <p className="text-gray-600 mb-6">
              Thank you for your order! Your order has been received and is being processed.
            </p>
            
            <div className="border-t border-gray-200 pt-6 mb-6">
              <p className="text-sm text-gray-500 mb-2">Order number</p>
              <p className="text-lg font-semibold text-gray-900">{state.orderId}</p>
            </div>
            
            <div className="grid grid-cols-1 md:grid-cols-3 gap-4 mb-8">
              <div className="bg-gray-50 rounded-lg p-4">
                <ShoppingBag size={24} className="text-blue-600 mx-auto mb-2" />
                <p className="text-sm text-gray-500 mb-1">Order Total</p>
                <p className="font-semibold text-gray-900">{formatPrice(state.total)}</p>
              </div>
              
              <div className="bg-gray-50 rounded-lg p-4">
                <Truck size={24} className="text-blue-600 mx-auto mb-2" />
                <p className="text-sm text-gray-500 mb-1">Shipping To</p>
                <p className="font-semibold text-gray-900 text-xs sm:text-sm">{state.shippingAddress}</p>
              </div>
              
              <div className="bg-gray-50 rounded-lg p-4">
                <Phone size={24} className="text-blue-600 mx-auto mb-2" />
                <p className="text-sm text-gray-500 mb-1">Payment Method</p>
                <p className="font-semibold text-gray-900">{formatPaymentMethod(state.paymentMethod)}</p>
              </div>
            </div>
            
            <div className="border-t border-gray-200 pt-6 mb-8">
              <p className="text-sm text-gray-600 mb-4">
                We'll send you shipping confirmation when your order ships. 
                Expected delivery time is 3-5 business days.
              </p>
              
              <div className="flex flex-col sm:flex-row items-center justify-center gap-4">
                <Link to="/">
                  <Button variant="primary">
                    Continue Shopping
                  </Button>
                </Link>
                
                <Link to="/track-order">
                  <Button variant="outline">
                    Track Order
                  </Button>
                </Link>
              </div>
            </div>
            
            <div className="text-sm text-gray-500">
              <p>
                Need help with your order?{' '}
                <Link to="/contact" className="text-blue-600 hover:text-blue-800">
                  Contact Support
                </Link>
              </p>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default OrderSuccess;