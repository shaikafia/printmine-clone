import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { useForm } from 'react-hook-form';
import { useCartStore } from '../store';
import { getProduct, formatPrice, getProductPrice, generateOrderId } from '../utils/helpers';
import Button from '../components/UI/Button';
import { CreditCard, Truck, Shield } from 'lucide-react';

interface CheckoutFormData {
  firstName: string;
  lastName: string;
  email: string;
  phone: string;
  address: string;
  city: string;
  state: string;
  pincode: string;
  paymentMethod: 'card' | 'upi' | 'cod';
  saveInfo: boolean;
}

const Checkout: React.FC = () => {
  const navigate = useNavigate();
  const { items, getSubtotal, clearCart } = useCartStore();
  const [orderProcessing, setOrderProcessing] = useState(false);
  
  const { register, handleSubmit, formState: { errors } } = useForm<CheckoutFormData>({
    defaultValues: {
      paymentMethod: 'card',
      saveInfo: true
    }
  });
  
  // If cart is empty, redirect to cart page
  if (items.length === 0) {
    navigate('/cart');
    return null;
  }
  
  const subtotal = getSubtotal(getProductPrice);
  const shipping = 0; // Free shipping
  const tax = subtotal * 0.18; // 18% GST
  const total = subtotal + shipping + tax;
  
  const onSubmit = async (data: CheckoutFormData) => {
    setOrderProcessing(true);
    
    try {
      // This would be a real API call in a production app
      // But for this demo, we'll just simulate an order process
      
      // Simulate API delay
      await new Promise(resolve => setTimeout(resolve, 1500));
      
      // Order successful
      const orderId = generateOrderId();
      
      // Clear cart
      clearCart();
      
      // Navigate to success page
      navigate('/order-success', { 
        state: { 
          orderId,
          total,
          shippingAddress: `${data.address}, ${data.city}, ${data.state} - ${data.pincode}`,
          paymentMethod: data.paymentMethod
        } 
      });
    } catch (error) {
      console.error('Order processing error:', error);
      setOrderProcessing(false);
      // Handle error (would show an error notification in a real app)
    }
  };

  return (
    <div className="bg-gray-50 pt-24 pb-12">
      <div className="container mx-auto px-4">
        <h1 className="text-3xl font-bold text-gray-900 mb-8">Checkout</h1>
        
        <div className="lg:grid lg:grid-cols-3 lg:gap-8">
          {/* Checkout Form */}
          <div className="lg:col-span-2">
            <form onSubmit={handleSubmit(onSubmit)}>
              {/* Contact Information */}
              <div className="bg-white rounded-lg shadow-sm overflow-hidden mb-6">
                <div className="p-6">
                  <h2 className="text-lg font-semibold text-gray-900 mb-4">Contact Information</h2>
                  
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-4 mb-4">
                    <div>
                      <label htmlFor="firstName" className="block text-sm font-medium text-gray-700 mb-1">
                        First Name
                      </label>
                      <input
                        id="firstName"
                        type="text"
                        className={`w-full rounded-md border ${errors.firstName ? 'border-red-500' : 'border-gray-300'} px-3 py-2 focus:outline-none focus:ring-2 focus:ring-blue-500`}
                        {...register('firstName', { required: 'First name is required' })}
                      />
                      {errors.firstName && (
                        <p className="mt-1 text-sm text-red-600">{errors.firstName.message}</p>
                      )}
                    </div>
                    
                    <div>
                      <label htmlFor="lastName" className="block text-sm font-medium text-gray-700 mb-1">
                        Last Name
                      </label>
                      <input
                        id="lastName"
                        type="text"
                        className={`w-full rounded-md border ${errors.lastName ? 'border-red-500' : 'border-gray-300'} px-3 py-2 focus:outline-none focus:ring-2 focus:ring-blue-500`}
                        {...register('lastName', { required: 'Last name is required' })}
                      />
                      {errors.lastName && (
                        <p className="mt-1 text-sm text-red-600">{errors.lastName.message}</p>
                      )}
                    </div>
                  </div>
                  
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                    <div>
                      <label htmlFor="email" className="block text-sm font-medium text-gray-700 mb-1">
                        Email Address
                      </label>
                      <input
                        id="email"
                        type="email"
                        className={`w-full rounded-md border ${errors.email ? 'border-red-500' : 'border-gray-300'} px-3 py-2 focus:outline-none focus:ring-2 focus:ring-blue-500`}
                        {...register('email', { 
                          required: 'Email is required',
                          pattern: {
                            value: /^[A-Z0-9._%+-]+@[A-Z0-9.-]+\.[A-Z]{2,}$/i,
                            message: 'Invalid email address'
                          }
                        })}
                      />
                      {errors.email && (
                        <p className="mt-1 text-sm text-red-600">{errors.email.message}</p>
                      )}
                    </div>
                    
                    <div>
                      <label htmlFor="phone" className="block text-sm font-medium text-gray-700 mb-1">
                        Phone Number
                      </label>
                      <input
                        id="phone"
                        type="tel"
                        className={`w-full rounded-md border ${errors.phone ? 'border-red-500' : 'border-gray-300'} px-3 py-2 focus:outline-none focus:ring-2 focus:ring-blue-500`}
                        {...register('phone', { 
                          required: 'Phone number is required',
                          pattern: {
                            value: /^[0-9]{10}$/,
                            message: 'Please enter a valid 10-digit phone number'
                          }
                        })}
                      />
                      {errors.phone && (
                        <p className="mt-1 text-sm text-red-600">{errors.phone.message}</p>
                      )}
                    </div>
                  </div>
                </div>
              </div>
              
              {/* Shipping Address */}
              <div className="bg-white rounded-lg shadow-sm overflow-hidden mb-6">
                <div className="p-6">
                  <h2 className="text-lg font-semibold text-gray-900 mb-4">Shipping Address</h2>
                  
                  <div className="mb-4">
                    <label htmlFor="address" className="block text-sm font-medium text-gray-700 mb-1">
                      Street Address
                    </label>
                    <input
                      id="address"
                      type="text"
                      className={`w-full rounded-md border ${errors.address ? 'border-red-500' : 'border-gray-300'} px-3 py-2 focus:outline-none focus:ring-2 focus:ring-blue-500`}
                      {...register('address', { required: 'Address is required' })}
                    />
                    {errors.address && (
                      <p className="mt-1 text-sm text-red-600">{errors.address.message}</p>
                    )}
                  </div>
                  
                  <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                    <div>
                      <label htmlFor="city" className="block text-sm font-medium text-gray-700 mb-1">
                        City
                      </label>
                      <input
                        id="city"
                        type="text"
                        className={`w-full rounded-md border ${errors.city ? 'border-red-500' : 'border-gray-300'} px-3 py-2 focus:outline-none focus:ring-2 focus:ring-blue-500`}
                        {...register('city', { required: 'City is required' })}
                      />
                      {errors.city && (
                        <p className="mt-1 text-sm text-red-600">{errors.city.message}</p>
                      )}
                    </div>
                    
                    <div>
                      <label htmlFor="state" className="block text-sm font-medium text-gray-700 mb-1">
                        State
                      </label>
                      <input
                        id="state"
                        type="text"
                        className={`w-full rounded-md border ${errors.state ? 'border-red-500' : 'border-gray-300'} px-3 py-2 focus:outline-none focus:ring-2 focus:ring-blue-500`}
                        {...register('state', { required: 'State is required' })}
                      />
                      {errors.state && (
                        <p className="mt-1 text-sm text-red-600">{errors.state.message}</p>
                      )}
                    </div>
                    
                    <div>
                      <label htmlFor="pincode" className="block text-sm font-medium text-gray-700 mb-1">
                        PIN Code
                      </label>
                      <input
                        id="pincode"
                        type="text"
                        className={`w-full rounded-md border ${errors.pincode ? 'border-red-500' : 'border-gray-300'} px-3 py-2 focus:outline-none focus:ring-2 focus:ring-blue-500`}
                        {...register('pincode', { 
                          required: 'PIN code is required',
                          pattern: {
                            value: /^[0-9]{6}$/,
                            message: 'Please enter a valid 6-digit PIN code'
                          }
                        })}
                      />
                      {errors.pincode && (
                        <p className="mt-1 text-sm text-red-600">{errors.pincode.message}</p>
                      )}
                    </div>
                  </div>
                </div>
              </div>
              
              {/* Payment Method */}
              <div className="bg-white rounded-lg shadow-sm overflow-hidden mb-6">
                <div className="p-6">
                  <h2 className="text-lg font-semibold text-gray-900 mb-4">Payment Method</h2>
                  
                  <div className="space-y-4">
                    <div className="flex items-center">
                      <input
                        id="card"
                        type="radio"
                        value="card"
                        className="h-4 w-4 text-blue-600 border-gray-300 focus:ring-blue-500"
                        {...register('paymentMethod')}
                      />
                      <label htmlFor="card" className="ml-3 flex items-center">
                        <CreditCard size={20} className="mr-2 text-gray-600" />
                        <span className="text-gray-900">Credit/Debit Card</span>
                      </label>
                    </div>
                    
                    <div className="flex items-center">
                      <input
                        id="upi"
                        type="radio"
                        value="upi"
                        className="h-4 w-4 text-blue-600 border-gray-300 focus:ring-blue-500"
                        {...register('paymentMethod')}
                      />
                      <label htmlFor="upi" className="ml-3 block">
                        <span className="text-gray-900">UPI</span>
                      </label>
                    </div>
                    
                    <div className="flex items-center">
                      <input
                        id="cod"
                        type="radio"
                        value="cod"
                        className="h-4 w-4 text-blue-600 border-gray-300 focus:ring-blue-500"
                        {...register('paymentMethod')}
                      />
                      <label htmlFor="cod" className="ml-3 block">
                        <span className="text-gray-900">Cash on Delivery</span>
                      </label>
                    </div>
                  </div>
                  
                  <div className="mt-6">
                    <div className="flex items-center">
                      <input
                        id="saveInfo"
                        type="checkbox"
                        className="h-4 w-4 text-blue-600 border-gray-300 rounded focus:ring-blue-500"
                        {...register('saveInfo')}
                      />
                      <label htmlFor="saveInfo" className="ml-3 text-sm text-gray-600">
                        Save this information for faster checkout next time
                      </label>
                    </div>
                  </div>
                </div>
              </div>
              
              {/* Submit Button (Mobile) */}
              <div className="mt-8 lg:hidden">
                <Button
                  type="submit"
                  variant="primary"
                  fullWidth
                  size="lg"
                  disabled={orderProcessing}
                >
                  {orderProcessing ? 'Processing...' : 'Place Order'}
                </Button>
              </div>
            </form>
          </div>
          
          {/* Order Summary */}
          <div className="mt-8 lg:mt-0">
            <div className="bg-white rounded-lg shadow-sm p-6 sticky top-24">
              <h2 className="text-lg font-semibold text-gray-900 mb-4">Order Summary</h2>
              
              {/* Order Items */}
              <div className="max-h-80 overflow-y-auto mb-4">
                <div className="space-y-4">
                  {items.map(item => {
                    const product = getProduct(item.productId);
                    if (!product) return null;
                    
                    return (
                      <div key={item.productId} className="flex items-center">
                        <div className="w-16 h-16 flex-shrink-0">
                          <img 
                            src={product.images[0]} 
                            alt={product.name}
                            className="w-full h-full object-cover rounded-md"
                          />
                        </div>
                        <div className="ml-4 flex-1">
                          <h4 className="text-sm font-medium text-gray-900">{product.name}</h4>
                          <p className="text-sm text-gray-500">Qty: {item.quantity}</p>
                        </div>
                        <div className="text-right">
                          <p className="text-sm font-medium text-gray-900">
                            {formatPrice(getProductPrice(product.id, item.selectedOptions) * item.quantity)}
                          </p>
                        </div>
                      </div>
                    );
                  })}
                </div>
              </div>
              
              {/* Order Totals */}
              <div className="border-t border-gray-200 pt-4 space-y-4">
                <div className="flex justify-between text-sm text-gray-600">
                  <p>Subtotal</p>
                  <p>{formatPrice(subtotal)}</p>
                </div>
                
                <div className="flex justify-between text-sm text-gray-600">
                  <p>Shipping</p>
                  <p>{shipping === 0 ? 'Free' : formatPrice(shipping)}</p>
                </div>
                
                <div className="flex justify-between text-sm text-gray-600">
                  <p>Tax (18% GST)</p>
                  <p>{formatPrice(tax)}</p>
                </div>
                
                <div className="flex justify-between text-base font-semibold text-gray-900 pt-4 border-t border-gray-200">
                  <p>Total</p>
                  <p>{formatPrice(total)}</p>
                </div>
              </div>
              
              {/* Submit Button (Desktop) */}
              <div className="mt-6 hidden lg:block">
                <Button
                  type="submit"
                  variant="primary"
                  fullWidth
                  size="lg"
                  onClick={handleSubmit(onSubmit)}
                  disabled={orderProcessing}
                >
                  {orderProcessing ? 'Processing...' : 'Place Order'}
                </Button>
              </div>
              
              {/* Trust Badges */}
              <div className="mt-6">
                <div className="border-t border-gray-200 pt-4">
                  <div className="flex items-center justify-center space-x-4 text-sm text-gray-500">
                    <div className="flex items-center">
                      <Shield size={16} className="mr-1" />
                      <span>Secure Payment</span>
                    </div>
                    <div className="flex items-center">
                      <Truck size={16} className="mr-1" />
                      <span>Fast Delivery</span>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default Checkout;