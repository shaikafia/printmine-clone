import React, { useState, useEffect } from 'react';
import { useLocation } from 'react-router-dom';
import { products, categories } from '../data/products';
import ProductCard from '../components/UI/ProductCard';
import { SlidersHorizontal, X } from 'lucide-react';
import Button from '../components/UI/Button';

const Products: React.FC = () => {
  const location = useLocation();
  const queryParams = new URLSearchParams(location.search);
  const categoryParam = queryParams.get('category');

  const [activeCategory, setActiveCategory] = useState<string | null>(categoryParam);
  const [sortBy, setSortBy] = useState<string>('featured');
  const [priceRange, setPriceRange] = useState<[number, number]>([0, 3000]);
  const [filtersOpen, setFiltersOpen] = useState(false);
  
  // Reset filters when URL changes
  useEffect(() => {
    setActiveCategory(categoryParam);
  }, [categoryParam]);

  // Filter and sort products
  const filteredProducts = products.filter(product => {
    // Filter by category
    if (activeCategory && product.category !== activeCategory) {
      return false;
    }
    
    // Filter by price range
    if (product.price < priceRange[0] || product.price > priceRange[1]) {
      return false;
    }
    
    return true;
  });

  // Sort products
  const sortedProducts = [...filteredProducts].sort((a, b) => {
    switch (sortBy) {
      case 'priceLow':
        return a.price - b.price;
      case 'priceHigh':
        return b.price - a.price;
      case 'rating':
        return (b.rating || 0) - (a.rating || 0);
      default: // featured or any other
        return (b.featured ? 1 : 0) - (a.featured ? 1 : 0);
    }
  });

  return (
    <div className="bg-gray-50">
      <div className="bg-blue-600 py-16">
        <div className="container mx-auto px-4">
          <h1 className="text-3xl font-bold text-white mb-2">Products</h1>
          <p className="text-blue-100">
            {activeCategory 
              ? `Browse our ${categories.find(c => c.id === activeCategory)?.name.toLowerCase() || ''} collection`
              : 'Browse our complete collection of high-quality print products'}
          </p>
        </div>
      </div>
      
      <div className="container mx-auto px-4 py-8">
        <div className="lg:grid lg:grid-cols-4 lg:gap-8">
          {/* Mobile filter toggle */}
          <div className="flex justify-between items-center mb-4 lg:hidden">
            <Button
              variant="outline"
              size="sm"
              onClick={() => setFiltersOpen(!filtersOpen)}
              className="flex items-center"
            >
              <SlidersHorizontal size={18} className="mr-2" />
              Filters
            </Button>
            
            <div className="relative">
              <select 
                value={sortBy}
                onChange={(e) => setSortBy(e.target.value)}
                className="appearance-none bg-white border border-gray-300 rounded-md py-2 pl-3 pr-10 text-sm focus:outline-none focus:ring-2 focus:ring-blue-500"
              >
                <option value="featured">Featured</option>
                <option value="priceLow">Price: Low to High</option>
                <option value="priceHigh">Price: High to Low</option>
                <option value="rating">Highest Rated</option>
              </select>
              <div className="pointer-events-none absolute inset-y-0 right-0 flex items-center px-2 text-gray-700">
                <svg className="fill-current h-4 w-4" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 20 20">
                  <path d="M9.293 12.95l.707.707L15.657 8l-1.414-1.414L10 10.828 5.757 6.586 4.343 8z" />
                </svg>
              </div>
            </div>
          </div>
          
          {/* Sidebar with filters - mobile (overlay) */}
          <div className={`fixed inset-0 bg-gray-800 bg-opacity-75 z-40 transition-opacity duration-300 lg:hidden ${
            filtersOpen ? 'opacity-100' : 'opacity-0 pointer-events-none'
          }`}>
            <div className={`fixed inset-y-0 left-0 max-w-xs w-full bg-white shadow-xl z-50 transition-transform duration-300 transform ${
              filtersOpen ? 'translate-x-0' : '-translate-x-full'
            }`}>
              <div className="flex items-center justify-between p-4 border-b">
                <h3 className="text-lg font-medium">Filters</h3>
                <button 
                  onClick={() => setFiltersOpen(false)}
                  className="text-gray-500 hover:text-gray-700"
                >
                  <X size={20} />
                </button>
              </div>
              
              <div className="p-4 overflow-y-auto h-full pb-24">
                {/* Categories */}
                <div className="mb-6">
                  <h4 className="font-medium text-gray-900 mb-3">Categories</h4>
                  <div className="space-y-2">
                    <div 
                      className={`cursor-pointer ${activeCategory === null ? 'text-blue-600 font-medium' : 'text-gray-700'}`}
                      onClick={() => setActiveCategory(null)}
                    >
                      All Products
                    </div>
                    
                    {categories.map(category => (
                      <div 
                        key={category.id}
                        className={`cursor-pointer ${activeCategory === category.id ? 'text-blue-600 font-medium' : 'text-gray-700'}`}
                        onClick={() => setActiveCategory(category.id)}
                      >
                        {category.name}
                      </div>
                    ))}
                  </div>
                </div>
                
                {/* Price Range */}
                <div className="mb-6">
                  <h4 className="font-medium text-gray-900 mb-3">Price Range</h4>
                  <div className="flex items-center space-x-2">
                    <span>₹{priceRange[0]}</span>
                    <input
                      type="range"
                      min="0"
                      max="3000"
                      step="100"
                      value={priceRange[0]}
                      onChange={(e) => setPriceRange([parseInt(e.target.value), priceRange[1]])}
                      className="w-full"
                    />
                    <span>₹{priceRange[1]}</span>
                  </div>
                  <div className="flex items-center space-x-2 mt-2">
                    <span>₹{priceRange[0]}</span>
                    <input
                      type="range"
                      min="0"
                      max="3000"
                      step="100"
                      value={priceRange[1]}
                      onChange={(e) => setPriceRange([priceRange[0], parseInt(e.target.value)])}
                      className="w-full"
                    />
                    <span>₹{priceRange[1]}</span>
                  </div>
                </div>
                
                {/* Apply button */}
                <Button
                  variant="primary"
                  fullWidth
                  onClick={() => setFiltersOpen(false)}
                >
                  Apply Filters
                </Button>
              </div>
            </div>
          </div>
          
          {/* Sidebar filters - desktop */}
          <div className="hidden lg:block">
            <div className="bg-white rounded-lg shadow-sm p-6 sticky top-24">
              <h3 className="text-lg font-medium text-gray-900 mb-4">Filters</h3>
              
              {/* Categories */}
              <div className="mb-6">
                <h4 className="font-medium text-gray-900 mb-3">Categories</h4>
                <div className="space-y-2">
                  <div 
                    className={`cursor-pointer ${activeCategory === null ? 'text-blue-600 font-medium' : 'text-gray-700'}`}
                    onClick={() => setActiveCategory(null)}
                  >
                    All Products
                  </div>
                  
                  {categories.map(category => (
                    <div 
                      key={category.id}
                      className={`cursor-pointer ${activeCategory === category.id ? 'text-blue-600 font-medium' : 'text-gray-700'}`}
                      onClick={() => setActiveCategory(category.id)}
                    >
                      {category.name}
                    </div>
                  ))}
                </div>
              </div>
              
              {/* Price Range */}
              <div className="mb-6">
                <h4 className="font-medium text-gray-900 mb-3">Price Range</h4>
                <div>
                  <div className="flex justify-between mb-2">
                    <span className="text-sm text-gray-500">Min: ₹{priceRange[0]}</span>
                    <span className="text-sm text-gray-500">Max: ₹{priceRange[1]}</span>
                  </div>
                  <div className="space-y-4">
                    <input
                      type="range"
                      min="0"
                      max="3000"
                      step="100"
                      value={priceRange[0]}
                      onChange={(e) => setPriceRange([parseInt(e.target.value), priceRange[1]])}
                      className="w-full"
                    />
                    <input
                      type="range"
                      min="0"
                      max="3000"
                      step="100"
                      value={priceRange[1]}
                      onChange={(e) => setPriceRange([priceRange[0], parseInt(e.target.value)])}
                      className="w-full"
                    />
                  </div>
                </div>
              </div>
              
              {/* Sort By - Desktop */}
              <div>
                <h4 className="font-medium text-gray-900 mb-3">Sort By</h4>
                <select 
                  value={sortBy}
                  onChange={(e) => setSortBy(e.target.value)}
                  className="w-full bg-white border border-gray-300 rounded-md py-2 px-3 text-sm focus:outline-none focus:ring-2 focus:ring-blue-500"
                >
                  <option value="featured">Featured</option>
                  <option value="priceLow">Price: Low to High</option>
                  <option value="priceHigh">Price: High to Low</option>
                  <option value="rating">Highest Rated</option>
                </select>
              </div>
            </div>
          </div>
          
          {/* Product grid */}
          <div className="lg:col-span-3">
            <div className="mb-6">
              <p className="text-gray-600">
                Showing {sortedProducts.length} products
                {activeCategory && ` in ${categories.find(c => c.id === activeCategory)?.name}`}
              </p>
            </div>
            
            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6">
              {sortedProducts.map(product => (
                <ProductCard key={product.id} product={product} />
              ))}
            </div>
            
            {sortedProducts.length === 0 && (
              <div className="text-center py-12">
                <p className="text-lg text-gray-600">No products found matching your criteria.</p>
                <Button
                  variant="outline"
                  className="mt-4"
                  onClick={() => {
                    setActiveCategory(null);
                    setPriceRange([0, 3000]);
                  }}
                >
                  Reset Filters
                </Button>
              </div>
            )}
          </div>
        </div>
      </div>
    </div>
  );
};

export default Products;