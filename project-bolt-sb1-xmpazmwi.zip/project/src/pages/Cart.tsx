import React from 'react';
import { Link, useNavigate } from 'react-router-dom';
import { Trash2, AlertCircle, ArrowRight } from 'lucide-react';
import { useCartStore } from '../store';
import { getProduct, formatPrice, getProductPrice } from '../utils/helpers';
import Button from '../components/UI/Button';

const Cart: React.FC = () => {
  const navigate = useNavigate();
  const { items, removeItem, updateQuantity, getSubtotal } = useCartStore();
  
  if (items.length === 0) {
    return (
      <div className="container mx-auto px-4 py-16 text-center">
        <div className="max-w-md mx-auto bg-white p-8 rounded-lg shadow-sm">
          <div className="w-16 h-16 bg-blue-100 text-blue-600 rounded-full flex items-center justify-center mx-auto mb-6">
            <AlertCircle size={32} />
          </div>
          <h2 className="text-2xl font-bold text-gray-800 mb-4">Your cart is empty</h2>
          <p className="text-gray-600 mb-8">Looks like you haven't added any products to your cart yet.</p>
          <Link to="/products">
            <Button variant="primary" fullWidth>
              Start Shopping
            </Button>
          </Link>
        </div>
      </div>
    );
  }

  return (
    <div className="bg-gray-50 pt-24 pb-12">
      <div className="container mx-auto px-4">
        <h1 className="text-3xl font-bold text-gray-900 mb-8">Shopping Cart</h1>
        
        <div className="lg:grid lg:grid-cols-3 lg:gap-8">
          {/* Cart Items */}
          <div className="lg:col-span-2">
            <div className="bg-white rounded-lg shadow-sm overflow-hidden mb-6">
              <div className="divide-y divide-gray-200">
                {items.map(item => {
                  const product = getProduct(item.productId);
                  if (!product) return null;
                  
                  return (
                    <div key={item.productId} className="p-4 sm:p-6">
                      <div className="flex flex-col sm:flex-row">
                        {/* Product Image */}
                        <div className="w-full sm:w-24 h-24 mb-4 sm:mb-0 flex-shrink-0">
                          <img 
                            src={product.images[0]} 
                            alt={product.name}
                            className="w-full h-full object-cover rounded-md"
                          />
                        </div>
                        
                        {/* Product Details */}
                        <div className="sm:ml-6 flex-1">
                          <div className="flex justify-between items-start">
                            <div>
                              <h3 className="text-lg font-semibold text-gray-900">
                                <Link to={`/products/${product.id}`} className="hover:text-blue-600">
                                  {product.name}
                                </Link>
                              </h3>
                              
                              {/* Selected Options */}
                              {item.selectedOptions && Object.keys(item.selectedOptions).length > 0 && (
                                <div className="mt-1 space-y-1">
                                  {Object.entries(item.selectedOptions).map(([optionId, value]) => {
                                    const option = product.customizationOptions?.find(o => o.id === optionId);
                                    return option ? (
                                      <p key={optionId} className="text-sm text-gray-600">
                                        {option.name}: {value}
                                      </p>
                                    ) : null;
                                  })}
                                </div>
                              )}
                            </div>
                            
                            <div className="text-right">
                              <p className="font-medium text-gray-900">
                                {formatPrice(getProductPrice(product.id, item.selectedOptions))}
                              </p>
                            </div>
                          </div>
                          
                          <div className="mt-4 flex items-center justify-between">
                            {/* Quantity */}
                            <div className="flex items-center border border-gray-300 rounded-md">
                              <button
                                className="px-3 py-1 hover:bg-gray-100"
                                onClick={() => updateQuantity(item.productId, item.quantity - 1)}
                                disabled={item.quantity <= 1}
                              >
                                -
                              </button>
                              <span className="px-3 py-1 border-x border-gray-300">{item.quantity}</span>
                              <button
                                className="px-3 py-1 hover:bg-gray-100"
                                onClick={() => updateQuantity(item.productId, item.quantity + 1)}
                              >
                                +
                              </button>
                            </div>
                            
                            {/* Remove Button */}
                            <button
                              className="text-red-600 hover:text-red-800 flex items-center"
                              onClick={() => removeItem(item.productId)}
                            >
                              <Trash2 size={18} className="mr-1" />
                              <span className="text-sm">Remove</span>
                            </button>
                          </div>
                        </div>
                      </div>
                    </div>
                  );
                })}
              </div>
            </div>
            
            {/* Continue Shopping */}
            <div className="text-center sm:text-left">
              <Link to="/products" className="text-blue-600 hover:text-blue-800 text-sm flex items-center justify-center sm:justify-start">
                <ArrowRight size={16} className="mr-1 rotate-180" />
                Continue Shopping
              </Link>
            </div>
          </div>
          
          {/* Order Summary */}
          <div className="mt-8 lg:mt-0">
            <div className="bg-white rounded-lg shadow-sm p-6">
              <h2 className="text-lg font-semibold text-gray-900 mb-4">Order Summary</h2>
              
              <div className="space-y-4">
                <div className="flex justify-between text-base text-gray-600">
                  <p>Subtotal</p>
                  <p>{formatPrice(getSubtotal(getProductPrice))}</p>
                </div>
                
                <div className="flex justify-between text-base text-gray-600">
                  <p>Shipping</p>
                  <p>Free</p>
                </div>
                
                <div className="flex justify-between text-base text-gray-600">
                  <p>Tax (18% GST)</p>
                  <p>{formatPrice(getSubtotal(getProductPrice) * 0.18)}</p>
                </div>
                
                <div className="border-t border-gray-200 pt-4 flex justify-between text-lg font-semibold text-gray-900">
                  <p>Total</p>
                  <p>{formatPrice(getSubtotal(getProductPrice) * 1.18)}</p>
                </div>
              </div>
              
              <div className="mt-6">
                <Button 
                  variant="primary" 
                  fullWidth
                  size="lg"
                  onClick={() => navigate('/checkout')}
                >
                  Proceed to Checkout
                </Button>
              </div>
              
              <div className="mt-6 text-sm text-gray-500">
                <p>
                  By proceeding to checkout, you agree to our{' '}
                  <Link to="/terms" className="text-blue-600 hover:text-blue-800">
                    Terms of Service
                  </Link>{' '}
                  and{' '}
                  <Link to="/privacy-policy" className="text-blue-600 hover:text-blue-800">
                    Privacy Policy
                  </Link>
                  .
                </p>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default Cart;