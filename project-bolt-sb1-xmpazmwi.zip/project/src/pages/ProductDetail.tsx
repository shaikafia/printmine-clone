import React, { useState } from 'react';
import { useParams, useNavigate } from 'react-router-dom';
import { getProduct, formatPrice } from '../utils/helpers';
import { useCartStore } from '../store';
import Button from '../components/UI/Button';
import { ChevronRight, Star, Truck, ShieldCheck, Award, ShoppingCart } from 'lucide-react';

const ProductDetail: React.FC = () => {
  const { id } = useParams<{ id: string }>();
  const navigate = useNavigate();
  const product = getProduct(id || '');
  
  const [quantity, setQuantity] = useState(1);
  const [selectedOptions, setSelectedOptions] = useState<Record<string, string>>({});
  const [activeImage, setActiveImage] = useState(0);
  
  const addToCart = useCartStore(state => state.addItem);
  
  // Handle if product not found
  if (!product) {
    return (
      <div className="container mx-auto px-4 py-16 text-center">
        <h2 className="text-2xl font-bold text-gray-800 mb-4">Product Not Found</h2>
        <p className="text-gray-600 mb-8">The product you're looking for doesn't exist or has been removed.</p>
        <Button variant="primary" onClick={() => navigate('/products')}>
          Continue Shopping
        </Button>
      </div>
    );
  }
  
  // Calculate price with selected options
  const calculatePrice = () => {
    let totalPrice = product.price;
    
    if (product.customizationOptions) {
      product.customizationOptions.forEach(option => {
        const selectedValue = selectedOptions[option.id];
        if (selectedValue && option.additionalPrice && option.additionalPrice[selectedValue]) {
          totalPrice += option.additionalPrice[selectedValue];
        }
      });
    }
    
    return totalPrice * quantity;
  };
  
  const handleAddToCart = () => {
    addToCart({
      productId: product.id,
      quantity,
      selectedOptions
    });
    
    // Show notification or redirect
    navigate('/cart');
  };
  
  const handleOptionChange = (optionId: string, value: string) => {
    setSelectedOptions(prev => ({
      ...prev,
      [optionId]: value
    }));
  };

  return (
    <div className="bg-gray-50 py-8 pt-24">
      <div className="container mx-auto px-4">
        {/* Breadcrumbs */}
        <div className="text-sm text-gray-500 mb-8 flex items-center">
          <span className="hover:text-blue-600 cursor-pointer" onClick={() => navigate('/')}>Home</span>
          <ChevronRight size={16} className="mx-2" />
          <span className="hover:text-blue-600 cursor-pointer" onClick={() => navigate('/products')}>Products</span>
          <ChevronRight size={16} className="mx-2" />
          <span className="hover:text-blue-600 cursor-pointer" onClick={() => navigate(`/products?category=${product.category}`)}>
            {product.category.charAt(0).toUpperCase() + product.category.slice(1)}
          </span>
          <ChevronRight size={16} className="mx-2" />
          <span className="text-gray-700">{product.name}</span>
        </div>
        
        <div className="bg-white rounded-lg shadow-sm overflow-hidden">
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3">
            {/* Product Images */}
            <div className="lg:col-span-2 p-4 md:p-8">
              <div className="grid grid-cols-1 md:grid-cols-5 gap-4">
                {/* Thumbnails - Desktop */}
                <div className="hidden md:flex md:flex-col space-y-4 order-1">
                  {product.images.map((image, index) => (
                    <div 
                      key={index}
                      className={`border-2 rounded-md cursor-pointer ${
                        activeImage === index ? 'border-blue-500' : 'border-gray-200 hover:border-gray-300'
                      }`}
                      onClick={() => setActiveImage(index)}
                    >
                      <img 
                        src={image} 
                        alt={`${product.name} - View ${index + 1}`}
                        className="h-16 w-16 object-cover"
                      />
                    </div>
                  ))}
                </div>
                
                {/* Main Image */}
                <div className="md:col-span-4 order-2">
                  <div className="aspect-w-1 aspect-h-1 w-full">
                    <img 
                      src={product.images[activeImage]} 
                      alt={product.name}
                      className="w-full h-full object-cover rounded-lg"
                    />
                  </div>
                </div>
                
                {/* Thumbnails - Mobile */}
                <div className="flex space-x-2 md:hidden order-3 mt-4">
                  {product.images.map((image, index) => (
                    <div 
                      key={index}
                      className={`border-2 rounded-md cursor-pointer ${
                        activeImage === index ? 'border-blue-500' : 'border-gray-200'
                      }`}
                      onClick={() => setActiveImage(index)}
                    >
                      <img 
                        src={image} 
                        alt={`${product.name} - View ${index + 1}`}
                        className="h-16 w-16 object-cover"
                      />
                    </div>
                  ))}
                </div>
              </div>
            </div>
            
            {/* Product Info */}
            <div className="p-4 md:p-8 border-l border-gray-200">
              <h1 className="text-2xl font-bold text-gray-900 mb-2">{product.name}</h1>
              
              {/* Rating */}
              {product.rating && (
                <div className="flex items-center mb-4">
                  <div className="flex text-yellow-400 mr-2">
                    {[...Array(5)].map((_, i) => (
                      <Star 
                        key={i} 
                        size={16} 
                        fill={i < Math.floor(product.rating || 0) ? 'currentColor' : 'none'} 
                      />
                    ))}
                  </div>
                  <span className="text-sm text-gray-600">
                    {product.rating} ({product.reviews} reviews)
                  </span>
                </div>
              )}
              
              {/* Price */}
              <div className="mb-6">
                <div className="text-3xl font-bold text-gray-900">
                  {formatPrice(calculatePrice())}
                </div>
                <p className="text-sm text-gray-500 mt-1">Including all taxes</p>
              </div>
              
              {/* Description */}
              <div className="mb-6">
                <p className="text-gray-700">{product.description}</p>
              </div>
              
              {/* Customization Options */}
              {product.customizationOptions && (
                <div className="space-y-6 mb-6">
                  {product.customizationOptions.map(option => (
                    <div key={option.id}>
                      <label className="block text-sm font-medium text-gray-700 mb-2">
                        {option.name}
                      </label>
                      <div className="flex flex-wrap gap-2">
                        {option.options.map(value => (
                          <button
                            key={value}
                            type="button"
                            className={`
                              py-2 px-4 border rounded-md text-sm font-medium
                              ${selectedOptions[option.id] === value
                                ? 'bg-blue-50 border-blue-500 text-blue-700'
                                : 'border-gray-300 text-gray-700 hover:bg-gray-50'
                              }
                            `}
                            onClick={() => handleOptionChange(option.id, value)}
                          >
                            {value}
                            {option.additionalPrice?.[value] && (
                              <span className="ml-1 text-gray-500">
                                (+{formatPrice(option.additionalPrice[value])})
                              </span>
                            )}
                          </button>
                        ))}
                      </div>
                    </div>
                  ))}
                </div>
              )}
              
              {/* Quantity */}
              <div className="mb-6">
                <label className="block text-sm font-medium text-gray-700 mb-2">
                  Quantity
                </label>
                <div className="flex items-center">
                  <button
                    className="border border-gray-300 rounded-l-md p-2 hover:bg-gray-100"
                    onClick={() => setQuantity(Math.max(1, quantity - 1))}
                  >
                    -
                  </button>
                  <input
                    type="number"
                    min="1"
                    value={quantity}
                    onChange={(e) => setQuantity(Math.max(1, parseInt(e.target.value) || 1))}
                    className="w-16 border-y border-gray-300 p-2 text-center focus:outline-none"
                  />
                  <button
                    className="border border-gray-300 rounded-r-md p-2 hover:bg-gray-100"
                    onClick={() => setQuantity(quantity + 1)}
                  >
                    +
                  </button>
                </div>
              </div>
              
              {/* Add to Cart Button */}
              <div className="mb-6">
                <Button
                  variant="primary"
                  fullWidth
                  onClick={handleAddToCart}
                  className="py-3"
                >
                  <ShoppingCart size={20} className="mr-2" />
                  Add to Cart
                </Button>
              </div>
              
              {/* Product Features */}
              <div className="border-t border-gray-200 pt-6 space-y-4">
                <div className="flex items-start">
                  <Truck size={20} className="text-blue-600 mr-3 flex-shrink-0" />
                  <div>
                    <h4 className="font-medium text-gray-900">Fast Delivery</h4>
                    <p className="text-sm text-gray-500">Delivered within 3-5 business days</p>
                  </div>
                </div>
                <div className="flex items-start">
                  <ShieldCheck size={20} className="text-blue-600 mr-3 flex-shrink-0" />
                  <div>
                    <h4 className="font-medium text-gray-900">Quality Guarantee</h4>
                    <p className="text-sm text-gray-500">High-quality materials and printing</p>
                  </div>
                </div>
                <div className="flex items-start">
                  <Award size={20} className="text-blue-600 mr-3 flex-shrink-0" />
                  <div>
                    <h4 className="font-medium text-gray-900">Satisfaction Guaranteed</h4>
                    <p className="text-sm text-gray-500">30-day easy returns</p>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default ProductDetail;