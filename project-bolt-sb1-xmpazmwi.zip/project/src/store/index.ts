import { create } from 'zustand';
import { persist } from 'zustand/middleware';
import { CartItem, User } from '../types';

interface CartState {
  items: CartItem[];
  addItem: (item: CartItem) => void;
  removeItem: (productId: string) => void;
  updateQuantity: (productId: string, quantity: number) => void;
  clearCart: () => void;
  getItemCount: () => number;
  getSubtotal: (getProductPrice: (id: string, options?: Record<string, string>) => number) => number;
}

interface AuthState {
  user: User | null;
  isAuthenticated: boolean;
  login: (user: User) => void;
  logout: () => void;
}

export const useCartStore = create<CartState>()(
  persist(
    (set, get) => ({
      items: [],
      addItem: (item) => set((state) => {
        const existingItemIndex = state.items.findIndex(
          (i) => i.productId === item.productId
        );
        
        if (existingItemIndex >= 0) {
          const updatedItems = [...state.items];
          updatedItems[existingItemIndex].quantity += item.quantity;
          return { items: updatedItems };
        }
        
        return { items: [...state.items, item] };
      }),
      removeItem: (productId) => set((state) => ({
        items: state.items.filter((item) => item.productId !== productId)
      })),
      updateQuantity: (productId, quantity) => set((state) => ({
        items: state.items.map((item) => 
          item.productId === productId 
            ? { ...item, quantity: Math.max(1, quantity) } 
            : item
        )
      })),
      clearCart: () => set({ items: [] }),
      getItemCount: () => {
        return get().items.reduce((acc, item) => acc + item.quantity, 0);
      },
      getSubtotal: (getProductPrice) => {
        return get().items.reduce(
          (total, item) => total + (getProductPrice(item.productId, item.selectedOptions) * item.quantity), 
          0
        );
      }
    }),
    {
      name: 'cart-storage',
    }
  )
);

export const useAuthStore = create<AuthState>()(
  persist(
    (set) => ({
      user: null,
      isAuthenticated: false,
      login: (user) => set({ user, isAuthenticated: true }),
      logout: () => set({ user: null, isAuthenticated: false })
    }),
    {
      name: 'auth-storage',
    }
  )
);