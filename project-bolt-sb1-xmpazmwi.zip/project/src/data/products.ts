import { Product, Category } from '../types';

export const products: Product[] = [
  {
    id: "1",
    name: "Custom T-Shirt",
    description: "High-quality cotton t-shirt with your custom design. Perfect for events, teams, or personal use.",
    price: 499,
    category: "apparel",
    images: [
      "https://images.pexels.com/photos/5709661/pexels-photo-5709661.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=2",
      "https://images.pexels.com/photos/4946398/pexels-photo-4946398.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=2"
    ],
    customizationOptions: [
      {
        id: "size",
        name: "Size",
        options: ["S", "M", "L", "XL", "XXL"],
        additionalPrice: { "XXL": 50 }
      },
      {
        id: "color",
        name: "Color",
        options: ["White", "Black", "Blue", "Red"]
      }
    ],
    featured: true,
    rating: 4.8,
    reviews: 124
  },
  {
    id: "2",
    name: "Business Cards",
    description: "Professional business cards printed on premium paper stock. Choose from multiple finishes.",
    price: 299,
    category: "stationery",
    images: [
      "https://images.pexels.com/photos/6177607/pexels-photo-6177607.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=2",
      "https://images.pexels.com/photos/6476123/pexels-photo-6476123.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=2"
    ],
    customizationOptions: [
      {
        id: "quantity",
        name: "Quantity",
        options: ["100", "250", "500", "1000"],
        additionalPrice: { "500": 200, "1000": 400 }
      },
      {
        id: "paperType",
        name: "Paper Type",
        options: ["Matte", "Glossy", "Textured"]
      }
    ],
    featured: true,
    rating: 4.6,
    reviews: 89
  },
  {
    id: "3",
    name: "Custom Mug",
    description: "Ceramic mug with your photo or design. Makes a perfect personalized gift.",
    price: 349,
    category: "gifts",
    images: [
      "https://images.pexels.com/photos/1793035/pexels-photo-1793035.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=2",
      "https://images.pexels.com/photos/6205509/pexels-photo-6205509.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=2"
    ],
    customizationOptions: [
      {
        id: "type",
        name: "Type",
        options: ["Standard", "Magic Mug"],
        additionalPrice: { "Magic Mug": 100 }
      }
    ],
    featured: true,
    rating: 4.7,
    reviews: 56
  },
  {
    id: "4",
    name: "Custom Calendar",
    description: "Personalized wall calendar with your own photos for each month.",
    price: 599,
    category: "stationery",
    images: [
      "https://images.pexels.com/photos/5499114/pexels-photo-5499114.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=2"
    ],
    rating: 4.9,
    reviews: 32
  },
  {
    id: "5",
    name: "Photo Canvas",
    description: "Turn your photos into stunning canvas prints. Available in multiple sizes.",
    price: 1299,
    category: "decor",
    images: [
      "https://images.pexels.com/photos/1616403/pexels-photo-1616403.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=2"
    ],
    customizationOptions: [
      {
        id: "size",
        name: "Size",
        options: ["12×12", "16×20", "24×36"],
        additionalPrice: { "16×20": 400, "24×36": 800 }
      }
    ],
    rating: 4.8,
    reviews: 75
  },
  {
    id: "6",
    name: "Letterhead",
    description: "Professional letterheads for your business correspondence. High-quality paper with your logo.",
    price: 449,
    category: "stationery",
    images: [
      "https://images.pexels.com/photos/6177619/pexels-photo-6177619.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=2"
    ],
    rating: 4.5,
    reviews: 18
  },
  {
    id: "7",
    name: "Custom Hoodie",
    description: "Warm and comfortable hoodie with your design. Perfect for cooler weather.",
    price: 899,
    category: "apparel",
    images: [
      "https://images.pexels.com/photos/6311387/pexels-photo-6311387.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=2"
    ],
    customizationOptions: [
      {
        id: "size",
        name: "Size",
        options: ["S", "M", "L", "XL", "XXL"],
        additionalPrice: { "XXL": 100 }
      },
      {
        id: "color",
        name: "Color",
        options: ["Black", "Gray", "Navy Blue"]
      }
    ],
    rating: 4.7,
    reviews: 42
  },
  {
    id: "8",
    name: "Promotional Banner",
    description: "Vinyl or fabric banner for your event or store. Weather-resistant and durable.",
    price: 1499,
    category: "marketing",
    images: [
      "https://images.pexels.com/photos/5763311/pexels-photo-5763311.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=2"
    ],
    customizationOptions: [
      {
        id: "size",
        name: "Size",
        options: ["3×6 ft", "4×8 ft", "6×10 ft"],
        additionalPrice: { "4×8 ft": 500, "6×10 ft": 1200 }
      },
      {
        id: "material",
        name: "Material",
        options: ["Vinyl", "Fabric", "Mesh"]
      }
    ],
    rating: 4.6,
    reviews: 28
  }
];

export const categories: Category[] = [
  {
    id: "apparel",
    name: "Apparel",
    image: "https://images.pexels.com/photos/5709661/pexels-photo-5709661.jpeg?auto=compress&cs=tinysrgb&w=600",
    description: "Custom t-shirts, hoodies, caps and more"
  },
  {
    id: "stationery",
    name: "Stationery",
    image: "https://images.pexels.com/photos/6177607/pexels-photo-6177607.jpeg?auto=compress&cs=tinysrgb&w=600",
    description: "Business cards, letterheads, calendars and more"
  },
  {
    id: "gifts",
    name: "Gifts",
    image: "https://images.pexels.com/photos/1793035/pexels-photo-1793035.jpeg?auto=compress&cs=tinysrgb&w=600",
    description: "Personalized mugs, keychains, and gift items"
  },
  {
    id: "decor",
    name: "Decor",
    image: "https://images.pexels.com/photos/1616403/pexels-photo-1616403.jpeg?auto=compress&cs=tinysrgb&w=600",
    description: "Canvas prints, posters, and wall art"
  },
  {
    id: "marketing",
    name: "Marketing",
    image: "https://images.pexels.com/photos/5763311/pexels-photo-5763311.jpeg?auto=compress&cs=tinysrgb&w=600",
    description: "Banners, flyers, brochures, and promotional materials"
  }
];