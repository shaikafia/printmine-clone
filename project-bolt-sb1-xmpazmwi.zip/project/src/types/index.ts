export interface Product {
  id: string;
  name: string;
  description: string;
  price: number;
  category: string;
  images: string[];
  customizationOptions?: CustomizationOption[];
  featured?: boolean;
  rating?: number;
  reviews?: number;
}

export interface CustomizationOption {
  id: string;
  name: string;
  options: string[];
  additionalPrice?: Record<string, number>;
}

export interface CartItem {
  productId: string;
  quantity: number;
  selectedOptions?: Record<string, string>;
}

export interface User {
  id: string;
  name: string;
  email: string;
}

export interface Category {
  id: string;
  name: string;
  image: string;
  description: string;
}