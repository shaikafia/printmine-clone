import React from 'react';
import { Link } from 'react-router-dom';
import Button from '../UI/Button';

const Hero: React.FC = () => {
  return (
    <div className="relative bg-gradient-to-r from-blue-800 to-blue-600 text-white">
      {/* Background pattern */}
      <div className="absolute inset-0 z-0 opacity-20" 
        style={{
          backgroundImage: 'url("data:image/svg+xml,%3Csvg width="60" height="60" viewBox="0 0 60 60" xmlns="http://www.w3.org/2000/svg"%3E%3Cg fill="none" fill-rule="evenodd"%3E%3Cg fill="%23ffffff" fill-opacity="0.4"%3E%3Cpath d="M36 34v-4h-2v4h-4v2h4v4h2v-4h4v-2h-4zm0-30V0h-2v4h-4v2h4v4h2V6h4V4h-4zM6 34v-4H4v4H0v2h4v4h2v-4h4v-2H6zM6 4V0H4v4H0v2h4v4h2V6h4V4H6z"/%3E%3C/g%3E%3C/g%3E%3C/svg%3E")',
        }}></div>
      
      <div className="container mx-auto px-4 pt-32 pb-24 relative z-10">
        <div className="flex flex-col md:flex-row items-center">
          {/* Left content */}
          <div className="w-full md:w-1/2 text-center md:text-left">
            <h1 className="text-4xl md:text-5xl lg:text-6xl font-bold leading-tight mb-4">
              Custom Printing <br />
              <span className="text-orange-400">Made Simple</span>
            </h1>
            <p className="text-lg md:text-xl text-blue-100 mb-8 max-w-lg">
              High-quality custom printing services for your business, events, or personal needs. Fast turnaround times and competitive prices.
            </p>
            <div className="flex flex-col sm:flex-row space-y-4 sm:space-y-0 sm:space-x-4 justify-center md:justify-start">
              <Link to="/products">
                <Button variant="secondary" size="lg">
                  Shop Now
                </Button>
              </Link>
              <Link to="/custom-quote">
                <Button variant="outline" size="lg" className="bg-white/10 text-white border-white/30 hover:bg-white/20">
                  Get Custom Quote
                </Button>
              </Link>
            </div>
            
            <div className="mt-12 flex flex-wrap justify-center md:justify-start">
              <div className="flex items-center mr-8 mb-4">
                <div className="w-12 h-12 bg-white/10 rounded-full flex items-center justify-center mr-3">
                  <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
                    <path d="M19 9V6a2 2 0 0 0-2-2H7a2 2 0 0 0-2 2v3"></path>
                    <path d="M3 16a2 2 0 0 0 2 2h14a2 2 0 0 0 2-2v-5a2 2 0 0 0-4 0v2H7v-2a2 2 0 0 0-4 0Z"></path>
                  </svg>
                </div>
                <div>
                  <p className="text-sm font-medium">Fast Delivery</p>
                  <p className="text-xs text-blue-200">2-5 Business Days</p>
                </div>
              </div>
              <div className="flex items-center mr-8 mb-4">
                <div className="w-12 h-12 bg-white/10 rounded-full flex items-center justify-center mr-3">
                  <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
                    <path d="M7.9 20A9 9 0 1 0 4 16.1L2 22Z"></path>
                    <path d="M12 8v4l2 2"></path>
                  </svg>
                </div>
                <div>
                  <p className="text-sm font-medium">24/7 Support</p>
                  <p className="text-xs text-blue-200">Always Available</p>
                </div>
              </div>
              <div className="flex items-center mb-4">
                <div className="w-12 h-12 bg-white/10 rounded-full flex items-center justify-center mr-3">
                  <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
                    <path d="M12 22s8-4 8-10V5l-8-3-8 3v7c0 6 8 10 8 10"></path>
                  </svg>
                </div>
                <div>
                  <p className="text-sm font-medium">High Quality</p>
                  <p className="text-xs text-blue-200">Premium Materials</p>
                </div>
              </div>
            </div>
          </div>
          
          {/* Right image/mockup */}
          <div className="w-full md:w-1/2 mt-12 md:mt-0">
            <div className="relative">
              <img 
                src="https://images.pexels.com/photos/5709661/pexels-photo-5709661.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=2" 
                alt="Custom T-Shirt" 
                className="rounded-lg shadow-2xl"
              />
              <div className="absolute -bottom-6 -left-6 bg-white p-4 rounded-lg shadow-lg transform rotate-3 hidden md:block">
                <div className="flex items-center">
                  <div className="text-blue-600 text-4xl font-bold mr-2">₹</div>
                  <div>
                    <div className="text-gray-800 font-bold text-xl">Starting from</div>
                    <div className="text-3xl font-bold text-gray-900">499</div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default Hero;