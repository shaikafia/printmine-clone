import React from 'react';

const steps = [
  {
    id: 1,
    title: 'Choose Your Product',
    description: 'Browse our catalog and select the product you want to customize.',
    icon: (
      <svg xmlns="http://www.w3.org/2000/svg" width="32" height="32" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
        <circle cx="10" cy="20.5" r="1"></circle>
        <circle cx="18" cy="20.5" r="1"></circle>
        <path d="M2.5 2h3l2.7 12.4a2 2 0 0 0 2 1.6h7.7a2 2 0 0 0 2-1.6L21.5 6H6"></path>
      </svg>
    ),
  },
  {
    id: 2,
    title: 'Customize It',
    description: 'Upload your design or use our design tool to create a custom look.',
    icon: (
      <svg xmlns="http://www.w3.org/2000/svg" width="32" height="32" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
        <path d="m6 9 6-6 6 6"></path>
        <path d="M12 3v18"></path>
      </svg>
    ),
  },
  {
    id: 3,
    title: 'Place Your Order',
    description: 'Review your design, add to cart, and complete the checkout process.',
    icon: (
      <svg xmlns="http://www.w3.org/2000/svg" width="32" height="32" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
        <rect width="6" height="14" x="4" y="5" rx="2"></rect>
        <rect width="6" height="10" x="14" y="9" rx="2"></rect>
        <path d="M22 19h-8"></path>
        <path d="M2 19h8"></path>
        <path d="M12 5v14"></path>
      </svg>
    ),
  },
  {
    id: 4,
    title: 'Fast Delivery',
    description: 'We print and ship your order, delivering it right to your doorstep.',
    icon: (
      <svg xmlns="http://www.w3.org/2000/svg" width="32" height="32" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
        <path d="M19 9V6a2 2 0 0 0-2-2H7a2 2 0 0 0-2 2v3"></path>
        <path d="M3 16a2 2 0 0 0 2 2h14a2 2 0 0 0 2-2v-5a2 2 0 0 0-4 0v2H7v-2a2 2 0 0 0-4 0Z"></path>
      </svg>
    ),
  },
];

const HowItWorks: React.FC = () => {
  return (
    <section className="py-16 bg-white">
      <div className="container mx-auto px-4">
        <div className="text-center mb-12">
          <h2 className="text-3xl font-bold text-gray-900 mb-3">How It Works</h2>
          <p className="text-gray-600 max-w-xl mx-auto">
            Getting your custom printed products is easy and straightforward with our simple process.
          </p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8">
          {steps.map((step, index) => (
            <div key={step.id} className="text-center">
              <div className="relative">
                <div className="w-16 h-16 bg-blue-100 text-blue-600 rounded-full flex items-center justify-center mx-auto mb-4">
                  {step.icon}
                </div>
                {index < steps.length - 1 && (
                  <div className="hidden lg:block absolute top-8 left-[calc(50%+2rem)] right-0 h-0.5 bg-blue-200">
                    <div className="w-2 h-2 rounded-full bg-blue-400 absolute -right-1 -top-0.5"></div>
                  </div>
                )}
              </div>
              <div className="bg-gray-50 rounded-lg p-6 transition-transform hover:translate-y-[-4px] duration-300">
                <h3 className="text-xl font-semibold text-gray-900 mb-2">{step.title}</h3>
                <p className="text-gray-600">{step.description}</p>
              </div>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
};

export default HowItWorks;