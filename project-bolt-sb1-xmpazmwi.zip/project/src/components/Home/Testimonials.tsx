import React from 'react';

const testimonials = [
  {
    id: 1,
    name: 'Priya Sharma',
    role: 'Event Manager',
    company: 'EventPro',
    image: 'https://images.pexels.com/photos/1239291/pexels-photo-1239291.jpeg?auto=compress&cs=tinysrgb&w=600',
    text: 'PrintMine delivered our event banners and t-shirts on time, and the quality was exceptional. Will definitely use their services again for our upcoming events.',
  },
  {
    id: 2,
    name: 'Rahul Mehta',
    role: 'Business Owner',
    company: 'CaféDelight',
    image: 'https://images.pexels.com/photos/2379004/pexels-photo-2379004.jpeg?auto=compress&cs=tinysrgb&w=600',
    text: 'The business cards and menu cards PrintMine created for my café received many compliments from customers. The designs were exactly what I wanted.',
  },
  {
    id: 3,
    name: 'Ananya Patel',
    role: 'Marketing Director',
    company: 'TechSolutions',
    image: 'https://images.pexels.com/photos/1987301/pexels-photo-1987301.jpeg?auto=compress&cs=tinysrgb&w=600',
    text: 'PrintMine has been our go-to printing partner for all marketing materials. Their attention to detail and consistent quality have helped our brand shine.',
  },
];

const Testimonials: React.FC = () => {
  return (
    <section className="py-16 bg-gray-50">
      <div className="container mx-auto px-4">
        <div className="text-center mb-12">
          <h2 className="text-3xl font-bold text-gray-900 mb-3">What Our Customers Say</h2>
          <p className="text-gray-600 max-w-xl mx-auto">
            Don't just take our word for it - hear from some of our satisfied customers!
          </p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
          {testimonials.map(testimonial => (
            <div key={testimonial.id} className="bg-white p-6 rounded-lg shadow-md hover:shadow-lg transition-shadow">
              <div className="flex items-center mb-4">
                <img 
                  src={testimonial.image} 
                  alt={testimonial.name} 
                  className="w-12 h-12 object-cover rounded-full mr-4"
                />
                <div>
                  <h4 className="font-semibold text-gray-900">{testimonial.name}</h4>
                  <p className="text-sm text-gray-600">{testimonial.role}, {testimonial.company}</p>
                </div>
              </div>
              <div className="mb-4">
                {[1, 2, 3, 4, 5].map(star => (
                  <span key={star} className="text-yellow-500">★</span>
                ))}
              </div>
              <p className="text-gray-700 italic">"{testimonial.text}"</p>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
};

export default Testimonials;